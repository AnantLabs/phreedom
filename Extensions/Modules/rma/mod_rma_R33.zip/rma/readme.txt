RMA Module 

Installation Procedure:
1. unzip and install in the module directory.
2. Go to Admin -> Modules and install the module.
3. You may have to set permission and re-log in.

NOTE: This module will be automatically installed if loaded 
when Phreedom is installed. If the module is added later, install
the module, the installer will not overwrite the database tables
if they are already there (from a prior release).
