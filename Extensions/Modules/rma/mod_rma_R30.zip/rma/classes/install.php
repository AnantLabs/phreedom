<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/rma/classes/install.php
//

class rma_admin {
  function rma_admin() {
	$this->notes = array(); // placeholder for any operational notes
	$this->prerequisites = array( // modules required and rev level for this module to work properly
	  'phreedom'   => '3.0',
	  'inventory'  => '3.0',
	  'phreebooks' => '3.0',
	);
	// Load configuration constants for this module, must match entries in general tab
    $this->keys = array();
	// Load tables
	$this->tables = array(
	  TABLE_RMA => "CREATE TABLE " . TABLE_RMA  . " (
		  id int(11) NOT NULL auto_increment,
		  rma_num varchar(16) NOT NULL,
		  entered_by int(11) default NULL,
		  return_code int(11) default NULL,
		  purchase_invoice_id varchar(24) default NULL,
		  caller_name varchar(32) NOT NULL default '',
		  caller_telephone1 varchar(32) NOT NULL default '',
		  caller_email varchar(48) default NULL,
		  caller_notes varchar(255) default NULL,
		  `status` varchar(3) NOT NULL default '',
		  received_by int(11) default NULL,
		  receive_carrier varchar(24) default NULL,
		  receive_tracking varchar(32) default NULL,
		  receive_notes varchar(255) default NULL,
		  creation_date date NOT NULL default '0000-00-00',
		  receive_date date NOT NULL default '0000-00-00',
		  closed_date date NOT NULL default '0000-00-00',
		  PRIMARY KEY  (id)
	    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;",	
	  TABLE_RMA_ITEM => "CREATE TABLE " . TABLE_RMA_ITEM  . " (
		  id int(11) NOT NULL auto_increment,
		  ref_id int(11) NOT NULL default '0',
		  qty float NOT NULL default '0',
		  sku varchar(16) NOT NULL default '',
		  item_action int(11) default NULL,
		  item_notes varchar(255) default NULL,
		  PRIMARY KEY  (id)
	    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;",
	);
  }

  function install($module) {
    global $db, $messageStack;
	$error = false;
    // add a current status field for the next rma number
    if (!db_field_exists(TABLE_CURRENT_STATUS, 'next_rma_num')) {
	  $db->Execute("ALTER TABLE " . TABLE_CURRENT_STATUS . " ADD next_rma_num VARCHAR( 16 ) NOT NULL DEFAULT 'RMA0001';");
	  $db->Execute("ALTER TABLE " . TABLE_CURRENT_STATUS . " ADD next_rma_desc VARCHAR( 32 ) NOT NULL DEFAULT 'MODULE_RMA_NEXT_SEQ';");
    }
    return $error;
  }

  function initialize($module) {
  }

  function update($module) {
    global $db;
    $error = false;
	if (!db_field_exists(TABLE_CURRENT_STATUS, 'next_rma_desc')) {
	  $db->Execute("ALTER TABLE " . TABLE_CURRENT_STATUS . " ADD next_rma_desc VARCHAR( 32 ) NOT NULL DEFAULT 'MODULE_RMA_NEXT_SEQ';");
    }
	write_configure('MODULE_' . strtoupper($module) . '_STATUS', constant('MODULE_' . strtoupper($module) . '_VERSION'));
    return $error;
  }

  function remove($module) {
    global $db;
	$error = false;
    if (db_field_exists(TABLE_CURRENT_STATUS, 'next_rma_num'))  $db->Execute("ALTER TABLE " . TABLE_CURRENT_STATUS . " DROP next_rma_num");
	if (db_field_exists(TABLE_CURRENT_STATUS, 'next_rma_desc')) $db->Execute("ALTER TABLE " . TABLE_CURRENT_STATUS . " DROP next_rma_desc");
    return $error;
  }

  function load_reports($module) {
  }

  function load_demo() {
  }

}
?>