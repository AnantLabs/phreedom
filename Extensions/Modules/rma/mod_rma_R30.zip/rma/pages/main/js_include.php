<?php
// +-----------------------------------------------------------------+
// |                   PhreeBooks Open Source ERP                    |
// +-----------------------------------------------------------------+
// | Copyright (c) 2008, 2009, 2010 PhreeSoft, LLC                   |
// | http://www.PhreeSoft.com                                        |
// +-----------------------------------------------------------------+
// | This program is free software: you can redistribute it and/or   |
// | modify it under the terms of the GNU General Public License as  |
// | published by the Free Software Foundation, either version 3 of  |
// | the License, or any later version.                              |
// |                                                                 |
// | This program is distributed in the hope that it will be useful, |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of  |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   |
// | GNU General Public License for more details.                    |
// |                                                                 |
// | The license that is bundled with this package is located in the |
// | file: /doc/manual/ch01-Introduction/license.html.               |
// | If not, see http://www.gnu.org/licenses/                        |
// +-----------------------------------------------------------------+
//  Path: /modules/rma/pages/main/js_include.php
//

?>
<script type="text/javascript">
<!--
// pass some php variables
var text_search       = '<?php echo TEXT_SEARCH; ?>';
var image_delete_text = '<?php echo TEXT_DELETE; ?>';
var image_delete_msg  = '<?php echo RMA_ROW_DELETE_ALERT; ?>';
var delete_icon_HTML  = '<?php echo substr(html_icon("emblems/emblem-unreadable.png", TEXT_DELETE, "small", "onclick=\"if (confirm(\'" . RMA_ROW_DELETE_ALERT . "\')) removeInvRow("), 0, -2); ?>';
<?php echo js_calendar_init($cal_create); ?>
<?php echo js_calendar_init($cal_rcv); ?>
<?php echo js_calendar_init($cal_close); ?>

<?php 
  echo $js_disp_code . chr(10);
  echo $js_disp_value . chr(10);
?>

// required function called with every page load
function init() {
  <?php if ($action <> 'new' && $action <> 'edit') { // set focus for main window
	echo "  document.getElementById('search_text').focus();";
	echo "  document.getElementById('search_text').select();";
  } ?>
}

function check_form() {
  var error = 0;
  var error_message = "<?php echo JS_ERROR; ?>";

  if (error == 1) {
	alert(error_message);
	return false;
  } else {
	return true;
  }
}

function ItemList(rowCnt) {
  var storeID = '0';
  window.open("index.php?module=inventory&page=popup_inv&rowID="+rowCnt+"&storeID="+storeID+"&search_text="+document.getElementById('sku_'+rowCnt).value,"inventory","width=700px,height=550px,resizable=1,scrollbars=1,top=150,left=200");
}

function loadSkuDetails(iID, rID) {
  var bID = 0;
  var cID = 0;
  var qty = 1;
  var jID = 10;
  var sku = '';
  if (!rID) return;
  if (!iID) sku = document.getElementById('sku_'+rID).value;  
  if (sku == text_search) return;
  $.ajax({
    type: "GET",
    contentType: "application/json; charset=utf-8",
    url: 'index.php?module=inventory&page=ajax&op=inv_details&fID=skuDetails&bID='+bID+'&cID='+cID+'&qty='+qty+'&iID='+iID+'&sku='+sku+'&rID='+rID+'&jID='+jID,
    dataType: ($.browser.msie) ? "text" : "xml",
    error: function(XMLHttpRequest, textStatus, errorThrown) {
      alert ("Ajax Error: " + XMLHttpRequest.responseText + "\nTextStatus: " + textStatus + "\nErrorThrown: " + errorThrown);
    },
	success: processSkuDetails,
  });
}

function processSkuDetails(sXml) { // call back function
  var xml = parseXml(sXml);
  if (!xml) return;
  var rID = $(xml).find("rID").text();
  document.getElementById('sku_' +rID).value       = $(xml).find("sku").text();
  document.getElementById('sku_' +rID).style.color = '';
  document.getElementById('desc_'+rID).value       = $(xml).find("description_short").text();
}

function deleteItem(id) {
  location.href = 'index.php?module=rma&page=main&action=delete&cID='+id;
}

function addItemRow() {
  var cell = Array();
  var newRow = document.getElementById('item_table').insertRow(-1);
  var newCell;
  rowCnt = newRow.rowIndex;

  cell[0] = '<td align="center">';
  cell[0] += buildIcon(icon_path+'16x16/emblems/emblem-unreadable.png', image_delete_text, 'onclick="if (confirm(\''+image_delete_msg+'\')) removeItemRow('+rowCnt+');"') + '<\/td>';
  cell[1] = '<td class="main" align="center"><input type="text" name="qty_'+rowCnt+'" id="qty_'+rowCnt+'"'+' size="7" maxlength="6" style="text-align:right"><\/td>';
  cell[2] = '<td nowrap="nowrap" class="main" align="center"><input type="text" name="sku_'+rowCnt+'" id="sku_'+rowCnt+'" value="'+text_search+'" size="12" maxlength="15" onfocus="clearField(\'sku_'+rowCnt+'\', \''+text_search+'\')" onblur="setField(\'sku_'+rowCnt+'\', \''+text_search+'\')">&nbsp;';
  cell[2] += buildIcon(icon_path+'16x16/status/folder-open.png', text_search, 'id="sku_open_'+rowCnt+'" align="top" style="cursor:pointer" onclick="ItemList('+rowCnt+')"') + '<\/td>';
// Hidden fields
  cell[2] += '<input type="hidden" name="id_'+rowCnt+'" id="id_'+rowCnt+'" value="">';
// End hidden fields
  cell[2] += '<\/td>';
  cell[3] = '<td class="main"><input type="text" name="desc_'+rowCnt+'" id="desc_'+rowCnt+'" size="64" maxlength="64"><\/td>';
  cell[4] = '<td class="main"><select name="actn_'+rowCnt+'" id="actn_'+rowCnt+'"><\/select><\/td>';

  for (var i=0; i<cell.length; i++) {
    newCell = newRow.insertCell(-1);
	newCell.innerHTML = cell[i];
  }
  // fill in the select list
  for (var i=0; i<js_disp_code.length; i++) {
	newOpt = document.createElement("option");
	newOpt.text = js_disp_value[i];
	document.getElementById('actn_'+rowCnt).options.add(newOpt);
	document.getElementById('actn_'+rowCnt).options[i].value = js_disp_code[i];
  }
  // change sku searh field to incative text color
  document.getElementById('sku_'+rowCnt).style.color = inactive_text_color;
  return rowCnt;
}

function removeItemRow(delRowCnt) {
  var acctIndex;
  // remove row from display by reindexing and then deleting last row
  for (var i = delRowCnt; i < (document.getElementById('item_table').rows.length - 1); i++) {
	document.getElementById('item_table').rows[i].cells[0].innerHTML = delete_icon_HTML + i + ');">';
	document.getElementById('qty_'+i).value  = document.getElementById('qty_'+(i+1)).value;
	document.getElementById('sku_'+i).value  = document.getElementById('sku_'+(i+1)).value;
	document.getElementById('desc_'+i).value = document.getElementById('desc_'+(i+1)).value;
	document.getElementById('actn_'+i).value = document.getElementById('actn_'+(i+1)).value;
// Hidden fields
	document.getElementById('id_'+i).value = document.getElementById('id_'+(i+1)).value;
// End hidden fields
  }
  document.getElementById('item_table').deleteRow(-1);
} 

// -->
</script>